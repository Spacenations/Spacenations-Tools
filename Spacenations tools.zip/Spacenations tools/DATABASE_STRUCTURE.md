# Datenbankstruktur — Firebase Firestore

Ersetzt die früheren, inzwischen widersprüchlichen Dokumente
`USER_DATABASE_STRUCTURE.md` und `FIREBASE_DATABASE_STRUCTURE.md`. Dies ist das
einzige, seit Juli 2026 einheitliche Rollen-/Datenmodell der App. Die
Durchsetzung erfolgt serverseitig über [`firestore.rules`](firestore.rules)
(getestet über `npm run test:rules`, siehe `tests/firestore-rules-simulator.js`)
— clientseitige Prüfungen in den `.html`/`.js`-Dateien sind nur UX, nicht die
eigentliche Sicherheitsgrenze.

## `users/{uid}`

Dokument-ID ist die Firebase-Auth-UID (nicht der Benutzername).

```javascript
{
  uid: "firebase-auth-uid",
  email: "user@example.com",
  username: "Anzeigename",        // bei Registrierung aus Vor-/Nachname zusammengesetzt
  createdAt: Timestamp,
  lastLogin: Timestamp,
  loginCount: 3,
  isActive: true,
  globalRole: "user"              // "user" | "global_admin"
}
```

**Sicherheitsregel (der Kern dieser ganzen Überarbeitung):** Jeder Nutzer darf
sein eigenes Dokument lesen/schreiben, aber `globalRole` ist davon
ausgenommen — das Feld kann nur ein bereits bestehender `global_admin` ändern
(auf beliebigen Nutzern). Ohne diese Ausnahme könnte sich jeder Nutzer per
Browser-Konsole (`db.collection('users').doc(uid).update({globalRole:
'global_admin'})`) selbst zum Admin machen; das war vor dieser Überarbeitung
tatsächlich möglich.

## `alliances/{allianceId}`

Dokument-ID ist eine auto-generierte Firestore-ID (kein Allianzname/-tag).

```javascript
{
  name: "Space Warriors",
  tag: "SW",                      // muss eindeutig sein (im Client per Query geprüft)
  description: "...",
  founderUid: "firebase-auth-uid",
  status: "pending",               // "pending" | "approved" | "rejected"
  createdAt: Timestamp,
  createdBy: "firebase-auth-uid",
  lastUpdated: Timestamp,
  reviewedAt: Timestamp,            // gesetzt, sobald ein Global-Admin über den Status entscheidet
  reviewedBy: "admin-uid"
}
```

Mitgliedschaft ist **nicht** mehr Teil dieses Dokuments (kein `members`-Array,
kein `admin`-Feld mehr) — sie lebt vollständig in `allianceMembers`. Jeder
angemeldete Nutzer darf alle `alliances`-Dokumente lesen (nötig für die
Tag-Eindeutigkeitsprüfung vor der Gründung); erstellen darf jeder nur für sich
selbst und nur mit `status: "pending"`; den Status ändern (genehmigen/ablehnen)
dürfen ausschließlich Global-Admins.

## `allianceMembers/{allianceId}_{uid}`

Flache Collection, Dokument-ID folgt immer dem Muster `<allianceId>_<uid>`
(kein Auto-ID). Das macht "bin ich Mitglied von X" zu einem einzelnen
`exists()`-Check statt einer Query — sowohl im Client als auch in den Regeln.

```javascript
{
  allianceId: "alliance-doc-id",
  uid: "firebase-auth-uid",
  username: "Anzeigename",
  role: "founder",                 // "founder" | "admin" | "member"
  permissions: {
    chatWrite: true,
    memberManage: true,
    spyDatabase: true
  },
  joinedAt: Timestamp
}
```

Ersetzt sowohl das alte `members`-Array auf dem Allianz-Dokument als auch die
früher getrennten, nie synchron gehaltenen Collections `alliancePermissions`
und `alliancePermissions/{id}/memberPermissions`. Erstellen darf ein
Allianz-/Global-Admin (für andere) oder der Gründer selbst — aber nur direkt im
Anschluss an die eigene Allianz-Gründung, verifiziert über einen serverseitigen
Abgleich mit `alliances/{allianceId}.founderUid`, damit sich niemand selbst als
Gründer einer fremden Allianz eintragen kann.

## `allianceChats/{allianceId}/messages/{messageId}`

```javascript
{
  content: "Nachrichtentext",
  authorUid: "firebase-auth-uid",
  timestamp: Timestamp
}
```

Nur für Mitglieder der jeweiligen Allianz lesbar/schreibbar. Nachrichten sind
unveränderlich (kein `update`), löschbar nur durch Allianz-/Global-Admins zu
Moderationszwecken.

## `allianceActivities/{activityId}`

Aktivitätsprotokoll pro Allianz (Beitritte, Rollenänderungen,
Allianz-Gründung, hinzugefügte Spionageberichte). Feldform ist bewusst locker
(`type` + freie Zusatzfelder), da noch keine UI diese Collection systematisch
zurückliest — sie dient primär der Nachvollziehbarkeit in der Datenbank
selbst.

```javascript
{
  allianceId: "alliance-doc-id",
  type: "member_added",            // z.B. member_added, member_removed, admin_changed,
                                    // alliance_created, spy_report_added, spy_report_deleted
  performedBy: "firebase-auth-uid",// bzw. performedByUid, je nach Aufrufer
  timestamp: Timestamp
  // + je nach "type" weitere Felder (member, newAdmin, details, ...)
}
```

Lesen/Schreiben ist auf Mitglieder der betroffenen Allianz beschränkt.

## `spyReports/{reportId}`

Vereinheitlicht die früher parallel existierenden Collections `spyReports`
(nur in Regeln/Beispielen benutzt) und `allianceSpyReports` (das tatsächlich
von der App geschriebene Schema) auf einen Namen.

```javascript
{
  reportId: "eindeutige-report-id",
  allianceId: "alliance-doc-id",   // ersetzt das frühere "allianceName"-Feld
  createdByUid: "firebase-auth-uid", // ersetzt das frühere "addedBy"
  createdAt: Timestamp,
  updatedAt: Timestamp,

  playerName: "Spielername",
  planetCoordinates: "555:395:3",
  planetName: "Planetenname",

  buildings: [ { name: "...", level: 12 }, /* ... */ ],
  shipTypes: [ { name: "...", count: 40 }, /* ... */ ],

  threatLevel: "high",
  totalAttackPower: 123456,
  totalDefensePower: 654321,
  totalResources: { metal: 1, crystal: 2, deuterium: 3 }
}
```

Lesen/Schreiben ist auf Mitglieder der Allianz beschränkt, der der Bericht
zugeordnet ist (`allianceId`); Löschen zusätzlich für den ursprünglichen
Ersteller (`createdByUid`) auch dann erlaubt, wenn er zwischenzeitlich kein
Allianz-Admin ist.

## `userBattles` / `userRaids` / `userSabotages`

Private Historie pro Nutzer für die drei Kampf-Tools, nie mit anderen geteilt.

```javascript
{
  userId: "firebase-auth-uid",
  timestamp: Timestamp,
  // + werkzeugspezifische Felder, z.B. bei userRaids:
  raidText: "...", resources: {...}, raidCount: 5,
  successfulRaids: 4, totalLoot: {...}, averageLoot: {...}, raidType: "resource_raid"
}
```

Nur der Eigentümer (`userId`) oder ein Global-Admin darf lesen/schreiben.
`userRaids` (aus `dashboard-raid-counter.html`) und `userSabotages` (aus
`js/sabo-counter.js`) werden aktiv beschrieben; `userBattles` ist in den Regeln
vorbereitet, aber `battle-counter.html` persistiert aktuell keine Ergebnisse.

## Migration vom alten Schema

`admin-migrate-schema.html` ist ein einmaliges, additives Migrationswerkzeug:
Es liest alle Dokumente im alten Schema (`isSuperAdmin`, `members`-Array,
`allianceSpyReports`, …) und schreibt die oben beschriebenen neuen Felder/
Collections zusätzlich dazu — nichts wird dabei gelöscht. Siehe die
Rollout-Reihenfolge in `README.md` für den genauen Ablauf (Tool einmal
ausführen → `firestore.rules` deployen → Tool-Seite löschen).
