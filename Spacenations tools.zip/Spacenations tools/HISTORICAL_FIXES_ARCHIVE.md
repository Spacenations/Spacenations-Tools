# Archiv: Historische Setup- & Fix-Dokumentation

Dieses Repository enthielt über 25 einzelne Markdown-Dateien im Root, die
nacheinander entstanden sind, während wiederkehrende Firebase- und
Deployment-Probleme behoben wurden. Im Zuge der Vereinheitlichung (Juli 2026)
wurden sie zu diesem einen Archiv zusammengefasst, da sie sich größtenteils
überschnitten oder bereits durch spätere Dateien überholt waren.

**Die Originaldateien sind gelöscht.** Der Inhalt unten ist rein historisch und
beschreibt teilweise Datenmodelle und Regeln, die in der aktuellen Version nicht
mehr existieren (`isSuperAdmin`, `systemRole`, `allianceRole`, ein `admin`-Feld
auf Allianz-Dokumenten, ein `members`-Array). Für den aktuellen Stand siehe
[`README.md`](README.md), [`DATABASE_STRUCTURE.md`](DATABASE_STRUCTURE.md) und
[`firestore.rules`](firestore.rules).

## Firebase-Einrichtung & Berechtigungsfehler

Ehemalige Dateien: `FIREBASE_CHECKLIST.md`, `FIREBASE_COMPLETE_SETUP.md`,
`FIREBASE_CONFIGURATION_CHECK.md`, `FIREBASE_PERMISSION_FIX.md`,
`FIREBASE_RULES_STEP_BY_STEP.md`, `FIREBASE_RULES_URGENT_FIX.md`,
`FIREBASE_RULES_VISUAL_GUIDE.md`, `FIREBASE_SECURITY_RULES_FIX.md`,
`FIREBASE_SETUP_ANLEITUNG.md`, `FIREBASE_SETUP_GUIDE.md`,
`FIREBASE_SETUP_WITH_SCREENSHOTS.md`, `FIREBASE_STATUS_SUMMARY.md`,
`QUICK_FIREBASE_FIX.md`, `QUICK_START_FIREBASE.md`, `README_FIREBASE_SETUP.md`,
`ADMIN_LOGIN_FIX.md`, `BENUTZERNAME_LOGIN_GUIDE.md`, `BROWSER_ERROR_HANDLING.md`,
`COMMIT_SUMMARY.md`, `FINAL_STATUS_CHECK.md`, `SYSTEM_REBUILD_SUMMARY.md`.

Diese ~20 Dateien entstanden nacheinander, während wiederholt
`Missing or insufficient permissions`-Fehler auftraten. Grundursache war fast
immer dieselbe: Die in der Firebase-Console eingespielten Firestore-Regeln
passten nicht zu den Feldern, die der Code tatsächlich schrieb und las
(z. B. ein `admin`-Feld auf dem Allianz-Dokument in den Regeln, während der
Code ein `members`-Array pflegte; `systemRole` in manchen Dateien geprüft,
`isSuperAdmin` in anderen; Login mal per Benutzername, mal per E-Mail
nachgeschlagen). Jede Datei war ein weiterer punktueller Reparaturversuch am
selben Grundkonflikt, statt eines einzigen konsistenten Schemas.

Die Vereinheitlichung auf `globalRole` + die flache `allianceMembers`-Collection
(siehe `DATABASE_STRUCTURE.md`) sowie die neu geschriebenen `firestore.rules`
lösen diesen Grundkonflikt strukturell: Es gibt jetzt nur noch eine Quelle der
Wahrheit für Rollen/Mitgliedschaft, gegen automatisierte Emulator-Tests
abgesichert (`npm run test:rules`).

Zusätzlich entfernt: drei veraltete Regel-Textdateien
(`firestore-security-rules.txt`, `firestore-security-rules-simple.txt`,
`FIRESTORE_RULES_FIX.txt`), auf die mehrere der obigen Dateien zum Kopieren in
die Firebase-Console verwiesen. Diese Dateien waren nicht nur veraltet, sondern
teils aktiv unsicher: Eine erlaubte `allow read, write: if request.auth != null`
für **alle** Dokumente in der Datenbank; eine andere erlaubte Nutzern weiterhin,
ihr eigenes `isSuperAdmin`-Feld selbst zu setzen — exakt die
Selbst-Beförderungs-Lücke, die diese Überarbeitung schließt.
**`firestore.rules` im Repo-Root ist die einzige gültige Quelle für
Firestore-Regeln; kopieren Sie Regeln nie aus einer anderen Datei.**

## Railway-Deployment

Ehemalige Dateien: `RAILWAY_DEPLOYMENT.md`, `RAILWAY_DEPLOYMENT_FIXED.md`,
`RAILWAY_DEPLOYMENT_FINAL.md`, `RAILWAY_DEPLOYMENT_ULTIMATE.md`,
`README_RAILWAY.md`.

Vier aufeinanderfolgende Versionen derselben Deployment-Anleitung, jede mit dem
Vermerk, ein Node.js/Python-Build-Problem nun endgültig behoben zu haben. Der
tatsächlich aktive Stand ist einfacher als alle vier Dokumente zusammen:
`Dockerfile.railway` (Python 3.9, `pip install -r requirements.txt`, Start via
`python app.py`), referenziert von `railway.json`, `railway.toml`, `Procfile`
und `nixpacks.toml` — alle vier konsistent zueinander. Aktuell beschrieben in
`README.md`.

## Warum archiviert statt kommentarlos gelöscht?

Falls in alten Commit-Messages, Issues oder Pull-Requests auf eine dieser
Dateien verwiesen wird, bleibt hier nachvollziehbar, worum es inhaltlich ging —
ohne dass weiterhin 28 einzelne, teils widersprüchliche und teils
sicherheitskritisch veraltete Dateien im Repo-Root gepflegt werden müssen.
