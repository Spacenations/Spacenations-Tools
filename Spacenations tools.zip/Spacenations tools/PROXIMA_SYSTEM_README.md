# Proxima-System

Verfolgt die aktuell verfügbaren Proxima-Planeten aus der Space-Nations-API.

## Tatsächliche Implementierung

Es gibt nur eine einzige, produktiv laufende Implementierung: **`ProximaDB.html`**,
zusätzlich im Admin-Dashboard unter dem Tab "ProximaDB" eingebettet
(`js/admin-dashboard-enhanced.js`). Sie holt die Daten direkt im Browser:

```javascript
const API_URL = 'https://beta1.game.spacenations.eu/api/proxima';
const AUTO_REFRESH_MS = 60000; // alle 60 Sekunden neu laden
```

- Kein Server, keine Datenbank, kein Cron-Job beteiligt — der Browser der
  Person, die die Seite geöffnet hat, ruft die API direkt auf.
- Bei einem fehlgeschlagenen Request greift ein Backoff (kein sofortiges
  Dauer-Retry-Spam gegen die Spiel-API).
- Daten sind nur so aktuell wie der zuletzt erfolgreiche Fetch im jeweils
  geöffneten Browser-Tab; es gibt keine geteilte, persistente Historie über
  mehrere Nutzer/Sitzungen hinweg.

### API-Antwortformat

```json
[
  {
    "name": "Proxima 10-1",
    "coordinates": "555:395:3",
    "score": 129,
    "deleteOn": "2025-09-17T16:06:58.000000Z"
  }
]
```

## Frühere Python/SQLite-Pipeline (entfernt)

Es gab zusätzlich eine komplett separate, nie tatsächlich produktiv laufende
Pipeline: `proxima_fetcher.py` / `proxima_simple.py` / `run_fetcher.py` sollten
per Cron-Job (`setup_cron.sh`) wöchentlich eine SQLite-Datenbank (`proxima.db`)
befüllen und daraus `proxima_report.html` / `proxima_data.json` generieren.

Diese Pipeline wurde im Zuge der Vereinheitlichung (Juli 2026) ersatzlos
entfernt, weil sie im echten Deployment nachweislich nie lief:
`Dockerfile.railway` kopiert zwar den Projektordner, aber
`.dockerignore`/`.railwayignore` schließen `*.db`-Dateien explizit aus, und
`app.py` enthielt zwar einen stündlichen Scheduler-Thread, der aber auf einen
Wochentag/Uhrzeit-Rhythmus prüfte, der nie mit einem tatsächlichen
Server-Neustart zusammenfiel — im Produktivbetrieb (Railway, kein
persistentes Volume) wurde `proxima.db` bei jedem Deploy ohnehin verworfen.
Kurz: Die Datei existierte im Repo, aber der Datenpfad, den sie beschrieb, war
in Produktion nie live.

`ProximaDB.html`s Direkt-Fetch-Ansatz umgeht dieses Problem komplett, indem er
gar keinen Server-Zustand braucht.
